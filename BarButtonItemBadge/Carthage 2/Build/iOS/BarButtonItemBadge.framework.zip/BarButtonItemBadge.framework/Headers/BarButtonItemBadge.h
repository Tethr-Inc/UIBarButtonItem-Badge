//
//  BarButtonItemBadge.h
//  BarButtonItemBadge
//
//  Created by Ian MacCallum on 12/1/16.
//  Copyright © 2016 Tethr. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIBarButtonItem+Badge.h"
#import "UIButton+Badge.h"

//! Project version number for BarButtonItemBadge.
FOUNDATION_EXPORT double BarButtonItemBadgeVersionNumber;

//! Project version string for BarButtonItemBadge.
FOUNDATION_EXPORT const unsigned char BarButtonItemBadgeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BarButtonItemBadge/PublicHeader.h>


